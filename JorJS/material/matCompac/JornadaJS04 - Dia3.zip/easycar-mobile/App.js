import Routes from "./src/routes.js";

export default function App() {
  return <>
    <Routes />
  </>;
}