import bg from "../assets/background.png";
import driver from "../assets/driver.png";
import passenger from "../assets/passenger.png";
import logo from "../assets/logo.png";
import location from "../assets/location.png";
import car from "../assets/car.png";

export default {
    bg, driver, passenger, logo, location, car
};
